package model;

public abstract class Personaje {
    protected String nombre;
    protected int energia, estructura, reflejos, foco;
    protected Efecto efectoActual;

    public Personaje(String nombre, int energia, int estructura, int reflejos, int foco) {
        this.nombre = nombre;
        this.energia = clamp(energia);
        this.estructura = clamp(estructura);
        this.reflejos = clamp(reflejos);
        this.foco = clamp(foco);
        this.efectoActual = null;
    }

    private int clamp(int v) { return Math.max(0, Math.min(v, 100)); }

    public boolean estaAgotado() { return energia <= 0; }
    public void aplicarEfecto(Efecto e) { this.efectoActual = e; }
    public void quitarEfecto() { this.efectoActual = null; }
    public Efecto getEfectoActual() { return efectoActual; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public int getEnergia() { return energia; }
    public String getClase() { return getClass().getSimpleName(); }

    public double getDesempeno() {
        double base = calcularDesempenoBase() * (energia / 100.0);
        if (efectoActual != null && efectoActual.estaActivo()) base = efectoActual.aplicar(base);
        return base;
    }

    protected abstract double calcularDesempenoBase();
}