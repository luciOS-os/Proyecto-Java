package model;

public class Asesino extends Personaje {
    public Asesino(String nombre) {
        super(nombre, 100, 0, 100, 0);
    }
    @Override
    protected double calcularDesempenoBase() { return reflejos; }
}