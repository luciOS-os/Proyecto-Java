package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Party {
    private final List<Personaje> personajes = new ArrayList<>();

    public boolean agregar(Personaje p) {
        if (personajes.size() >= 6) return false;
        if (buscarPorNombre(p.getNombre()).isPresent()) return false;
        long mismoTipo = personajes.stream().filter(x -> x.getClass().equals(p.getClass())).count();
        if (mismoTipo >= 2) return false;
        personajes.add(p);
        return true;
    }

    public boolean quitarPorNombre(String nombre) {
        Optional<Personaje> op = buscarPorNombre(nombre);
        if (op.isEmpty()) return false;
        Personaje p = op.get();
        if (!p.estaAgotado()) return false;
        return personajes.remove(p);
    }

    public boolean reemplazarPorNombre(String viejoNombre, Personaje nuevo) {
        Optional<Personaje> op = buscarPorNombre(viejoNombre);
        if (op.isEmpty()) return false;
        Personaje viejo = op.get();
        if (viejo.getEfectoActual() != null && !viejo.getEfectoActual().isPositivo()) return false;
        int idx = personajes.indexOf(viejo);
        if (idx == -1) return false;
        // check constraints for nuevo: name unique and max two per class (considering replacement)
        if (buscarPorNombre(nuevo.getNombre()).isPresent()) return false;
        long mismoTipo = personajes.stream()
                .filter(x -> x.getClass().equals(nuevo.getClass()))
                .count();
        // if the viejo is same class as nuevo, sameTipo already counts viejo; allow replace in that case
        if (!viejo.getClass().equals(nuevo.getClass()) && mismoTipo >= 2) return false;
        personajes.set(idx, nuevo);
        return true;
    }

    public Optional<Personaje> buscarPorNombre(String nombre) {
        return personajes.stream().filter(p -> p.getNombre().equals(nombre)).findFirst();
    }

    public List<Personaje> listar() { return new ArrayList<>(personajes); }

    public boolean modificarNombre(String viejo, String nuevo) {
        if (buscarPorNombre(nuevo).isPresent()) return false;
        Optional<Personaje> op = buscarPorNombre(viejo);
        if (op.isEmpty()) return false;
        op.get().setNombre(nuevo);
        return true;
    }
}