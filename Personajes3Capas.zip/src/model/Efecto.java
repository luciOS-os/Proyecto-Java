package model;

public class Efecto {
    private String nombre;
    private boolean positivo;
    private int duracion;
    private double modificador;

    public Efecto(String nombre, boolean positivo, int duracion, double modificador) {
        this.nombre = nombre;
        this.positivo = positivo;
        this.duracion = duracion;
        this.modificador = modificador;
    }

    public boolean estaActivo() { return duracion > 0; }
    public void reducirDuracion() { if (duracion > 0) duracion--; }
    public double aplicar(double desempeno) { return desempeno * modificador; }
    public String getNombre() { return nombre; }
    public boolean isPositivo() { return positivo; }
}