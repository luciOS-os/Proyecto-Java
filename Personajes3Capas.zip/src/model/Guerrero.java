package model;

public class Guerrero extends Personaje {
    public Guerrero(String nombre) {
        super(nombre, 100, 100, 0, 0);
    }
    @Override
    protected double calcularDesempenoBase() { return estructura; }
}