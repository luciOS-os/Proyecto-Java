package model;

public class Mago extends Personaje {
    public Mago(String nombre) {
        super(nombre, 100, 0, 0, 100);
    }
    @Override
    protected double calcularDesempenoBase() { return foco; }
}