package view;

import model.*;
import service.PartyService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AppFrame extends JFrame {
    private PartyService service;
    private DefaultTableModel tableModel;
    private JTable table;

    public AppFrame() {
        super("Gestión de Party - (3 capas)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 420);
        setLocationRelativeTo(null);

        service = new PartyService();

        tableModel = new DefaultTableModel(new Object[]{"Nombre", "Clase", "Energía", "Efecto"}, 0);
        table = new JTable(tableModel);

        JButton btnAgregar = new JButton("Agregar Personaje");
        JButton btnQuitar = new JButton("Quitar (si agotado)");
        JButton btnReemplazar = new JButton("Reemplazar");
        JButton btnRenombrar = new JButton("Renombrar");
        JButton btnActualizar = new JButton("Actualizar Lista");

        btnAgregar.addActionListener(e -> mostrarDialogoAgregar());
        btnQuitar.addActionListener(e -> quitarSeleccionado());
        btnReemplazar.addActionListener(e -> reemplazarSeleccionado());
        btnRenombrar.addActionListener(e -> renombrarSeleccionado());
        btnActualizar.addActionListener(e -> actualizarTabla());

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnAgregar);
        panelBotones.add(btnQuitar);
        panelBotones.add(btnReemplazar);
        panelBotones.add(btnRenombrar);
        panelBotones.add(btnActualizar);

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private void mostrarDialogoAgregar() {
        JTextField nombre = new JTextField();
        String[] clases = {"Guerrero", "Asesino", "Mago"};
        JComboBox<String> tipo = new JComboBox<>(clases);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombre);
        panel.add(new JLabel("Tipo:"));
        panel.add(tipo);

        int res = JOptionPane.showConfirmDialog(this, panel, "Nuevo Personaje", JOptionPane.OK_CANCEL_OPTION);
        if (res == JOptionPane.OK_OPTION) {
            String nom = nombre.getText().trim();
            if (nom.isEmpty()) { JOptionPane.showMessageDialog(this, "Nombre vacío."); return; }
            String clase = (String) tipo.getSelectedItem();

            Personaje p = switch (clase) {
                case "Guerrero" -> new Guerrero(nom);
                case "Asesino" -> new Asesino(nom);
                default -> new Mago(nom);
            };

            boolean ok = service.agregarPersonaje(p);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Personaje agregado con éxito.");
                actualizarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo agregar. Restricciones del Party (máx 6, no duplicados, max 2 por clase).");
            }
        }
    }

    private void actualizarTabla() {
        tableModel.setRowCount(0);
        List<Personaje> lista = service.listarPersonajes();
        for (Personaje p : lista) {
            tableModel.addRow(new Object[]{
                    p.getNombre(),
                    p.getClase(),
                    p.getEnergia(),
                    p.getEfectoActual() == null ? "Ninguno" : p.getEfectoActual().getNombre()
            });
        }
    }

    private Personaje getSeleccionado() {
        int r = table.getSelectedRow();
        if (r == -1) { JOptionPane.showMessageDialog(this, "Selecciona un personaje de la lista."); return null; }
        String nombre = (String) tableModel.getValueAt(r, 0);
        return service.buscarPorNombre(nombre);
    }

    private void quitarSeleccionado() {
        Personaje p = getSeleccionado();
        if (p == null) return;
        boolean ok = service.quitarPersonaje(p.getNombre());
        if (ok) {
            JOptionPane.showMessageDialog(this, "Personaje removido.");
            actualizarTabla();
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo quitar. Solo se puede quitar si está agotado.");
        }
    }

    private void reemplazarSeleccionado() {
        Personaje viejo = getSeleccionado();
        if (viejo == null) return;

        JTextField nombre = new JTextField();
        String[] clases = {"Guerrero", "Asesino", "Mago"};
        JComboBox<String> tipo = new JComboBox<>(clases);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("Nombre nuevo personaje:"));
        panel.add(nombre);
        panel.add(new JLabel("Tipo:"));
        panel.add(tipo);

        int res = JOptionPane.showConfirmDialog(this, panel, "Reemplazar personaje", JOptionPane.OK_CANCEL_OPTION);
        if (res == JOptionPane.OK_OPTION) {
            String nom = nombre.getText().trim();
            if (nom.isEmpty()) { JOptionPane.showMessageDialog(this, "Nombre vacío."); return; }
            String clase = (String) tipo.getSelectedItem();

            Personaje nuevo = switch (clase) {
                case "Guerrero" -> new Guerrero(nom);
                case "Asesino" -> new Asesino(nom);
                default -> new Mago(nom);
            };

            boolean ok = service.reemplazarPersonaje(viejo.getNombre(), nuevo);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Reemplazado con éxito.");
                actualizarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo reemplazar. Verifica si el personaje tiene efecto negativo activo o restricciones.");
            }
        }
    }

    private void renombrarSeleccionado() {
        Personaje p = getSeleccionado();
        if (p == null) return;
        String nuevo = JOptionPane.showInputDialog(this, "Nuevo nombre:", p.getNombre());
        if (nuevo == null) return;
        nuevo = nuevo.trim();
        if (nuevo.isEmpty()) { JOptionPane.showMessageDialog(this, "Nombre vacío."); return; }
        boolean ok = service.modificarNombre(p.getNombre(), nuevo);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Nombre modificado.");
            actualizarTabla();
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo modificar el nombre (quizá ya existe).");
        }
    }
}