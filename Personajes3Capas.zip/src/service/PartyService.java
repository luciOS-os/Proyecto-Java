package service;

import model.*;

import java.util.List;

public class PartyService {
    private final Party party = new Party();

    public boolean agregarPersonaje(Personaje p) {
        return party.agregar(p);
    }

    public boolean quitarPersonaje(String nombre) {
        return party.quitarPorNombre(nombre);
    }

    public boolean reemplazarPersonaje(String viejoNombre, Personaje nuevo) {
        return party.reemplazarPorNombre(viejoNombre, nuevo);
    }

    public java.util.List<Personaje> listarPersonajes() {
        return party.listar();
    }

    public Personaje buscarPorNombre(String nombre) {
        return party.buscarPorNombre(nombre).orElse(null);
    }

    public boolean modificarNombre(String viejo, String nuevo) {
        return party.modificarNombre(viejo, nuevo);
    }
}